import 'package:flutter/material.dart';
import 'package:todo_list/database_helper.dart';
import 'package:todo_list/todo.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '''Todo List''',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
            seedColor: const Color.fromARGB(255, 174, 235, 255)),
        useMaterial3: true,
      ),
      home: const NoaBook(title: '''Millenium's Todo List'''),
    );
  }
}

class NoaBook extends StatefulWidget {
  const NoaBook({super.key, required this.title});
  final String title;

  @override
  State<NoaBook> createState() => _NoaBookState();
}

class _NoaBookState extends State<NoaBook> {
  final TextEditingController _searchController = TextEditingController();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descController = TextEditingController();
  final dbHelper = DatabaseHelper();
  List<Todo> _todos = [];
  int _count = 0;

  void refreshItemList() async {
    final todos = await dbHelper.getAllTodos();
    setState(() {
      _todos = todos;
    });
  }

  void searchItems() async {
    final keyword = _searchController.text.trim();
    if (keyword.isNotEmpty) {
      final todos = await dbHelper.getTodoByTitle(keyword);
      setState(() {
        _todos = todos;
      });
    } else {
      refreshItemList();
    }
  }

  void addItem(String title, String desc) async {
    final todo = Todo(id: _count, title: title, desc: desc, completed: false);
    await dbHelper.insertTodo(todo);
    refreshItemList();
  }

  void updateItem(Todo todo, bool completed) async {
    final item = Todo(
      id: todo.id,
      title: todo.title,
      desc: todo.desc,
      completed: completed,
    );
    await dbHelper.updateTodo(item);
    refreshItemList();
  }

  void updateWholeItem(Todo todo, String title, String desc) async {
    final item = Todo(
      id: todo.id,
      title: title,
      desc: desc,
      completed: todo.completed,
    );
    await dbHelper.updateTodo(item);
    refreshItemList();
  }

  void deleteItem(int id) async {
    await dbHelper.deleteTodo(id);
    refreshItemList();
  }

  void clearQuery() async {
    _titleController.clear();
    _descController.clear();
  }

  @override
  void initState() {
    refreshItemList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 174, 235, 255),
        title: Text(widget.title),
      ),
      backgroundColor: const Color.fromRGBO(222, 247, 255, 1),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                labelText: 'Search',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              onChanged: (_) {
                searchItems();
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _todos.length,
              itemBuilder: (context, index) {
                var todo = _todos[index];
                return InkWell(
                  onTap: () {
                    _titleController.text = todo.title;
                    _descController.text = todo.desc;
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text('Update a Todo'),
                        content: SizedBox(
                          width: 200,
                          height: 200,
                          child: Column(
                            children: [
                              TextField(
                                controller: _titleController,
                                decoration:
                                    const InputDecoration(hintText: 'Title'),
                              ),
                              TextField(
                                controller: _descController,
                                decoration: const InputDecoration(
                                    hintText: 'Description'),
                              ),
                            ],
                          ),
                        ),
                        actions: [
                          TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                                clearQuery();
                              },
                              child: const Text('Cancel')),
                          TextButton(
                              onPressed: () {
                                updateWholeItem(todo, _titleController.text,
                                    _descController.text);

                                Navigator.pop(context);
                                clearQuery();
                              },
                              child: const Text('Update')),
                        ],
                      ),
                    );
                  },
                  child: Container(
                    decoration: const BoxDecoration(
                        color: Color.fromRGBO(222, 247, 255, 1),
                        gradient: RadialGradient(
                            radius: 3,
                            focal: Alignment.centerRight,
                            colors: [Colors.white, Colors.white70])),
                    child: ListTile(
                      tileColor: const Color.fromARGB(255, 174, 235, 255),
                      leading: todo.completed
                          ? IconButton(
                              onPressed: () {
                                updateItem(todo, !todo.completed);
                              },
                              icon: const Icon(Icons.check_circle),
                              color: Colors.blue,
                            )
                          : IconButton(
                              onPressed: () {
                                updateItem(todo, !todo.completed);
                              },
                              icon: const Icon(Icons.radio_button_unchecked),
                            ),
                      title: Text(todo.title),
                      subtitle: Text(todo.desc),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () {
                          showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                    title: const Text('Delete a Todo'),
                                    content: Text(
                                        'Are you sure you want to delete "${todo.title}"?'),
                                    actions: [
                                      TextButton(
                                          onPressed: () {
                                            Navigator.pop(context);
                                          },
                                          child: const Text("Cancel")),
                                      TextButton(
                                          onPressed: () {
                                            deleteItem(todo.id);
                                            Navigator.pop(context);
                                          },
                                          child: const Text("Delete")),
                                    ],
                                  ));
                        },
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color.fromARGB(255, 174, 235, 255),
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('Add a Todo'),
              content: SizedBox(
                width: 200,
                height: 200,
                child: Column(
                  children: [
                    TextField(
                      controller: _titleController,
                      decoration: const InputDecoration(hintText: 'Title'),
                    ),
                    TextField(
                      controller: _descController,
                      decoration:
                          const InputDecoration(hintText: 'Description'),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel')),
                TextButton(
                    onPressed: () {
                      addItem(_titleController.text, _descController.text);

                      Navigator.pop(context);
                      setState(() {
                        _count = _count + 1;
                      });
                      clearQuery();
                    },
                    child: const Text('Add')),
              ],
            ),
          );
        },
        tooltip: 'Add Note',
        child: const Icon(Icons.add),
      ),
    );
  }
}
